"use client"
import { useState } from "react";
import BookingType from "../components/booker/BookingType";
import { DownIcon } from "../components/icons/DownIcon";
import { FlightIcon } from "../components/icons/FlightIcon";
import { OneWayIcon } from "../components/icons/OneWayTrip";
import { RocketIcon } from "../components/icons/RocketIcon";
import { RoundTripIcon } from "../components/icons/RoundTripIcon";
import Example from "../components/Selector";

function Search() {
  return (
    <div className="container container-lg px-16">
      <div className="columns-4 px-4">
        <BookingType name="Uçak" selected={true}>
          <FlightIcon width="30px" height="30px" />
        </BookingType>
        <BookingType name="Uzay">
          <RocketIcon width="30px" height="30px" />
        </BookingType>
      </div>
      <div  className="mx-auto w-64 max-w-sm p-4">
        <Example />
      </div>
      <div className="rounded bg-stone-400">
        <div className="lg:columns-2">
          <div className="block">
            <input type="text" className="w-auto rounded" />
            <input type="date" className="w-auto rounded" />
          </div>
          <div>
            <input type="text" className="w-auto rounded " />
            <input type="date" className="w-auto rounded " />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Search;
