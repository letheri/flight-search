import { useState } from "react";
import { Listbox } from "@headlessui/react";
import { DownIcon } from "./icons/DownIcon";
import { CheckIcon } from "./icons/Check";
import { RoundTripIcon } from "./icons/RoundTripIcon";
import { OneWayIcon } from "./icons/OneWayTrip";

const people = [
  {
    id: 1,
    name: "Wade Cooper",
    avatar:
      "https://images.unsplash.com/photo-1491528323818-fdd1faba62cc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 2,
    name: "Arlene Mccoy",
    avatar:
      "https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 3,
    name: "Devon Webb",
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2.25&w=256&h=256&q=80",
  },
  {
    id: 4,
    name: "Tom Cook",
    avatar:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 5,
    name: "Tanya Fox",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 6,
    name: "Hellen Schmidt",
    avatar:
      "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 7,
    name: "Caroline Schultz",
    avatar:
      "https://images.unsplash.com/photo-1568409938619-12e139227838?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 8,
    name: "Mason Heaney",
    avatar:
      "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 9,
    name: "Claudie Smitham",
    avatar:
      "https://images.unsplash.com/photo-1584486520270-19eca1efcce5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
  {
    id: 10,
    name: "Emil Schaefer",
    avatar:
      "https://images.unsplash.com/photo-1561505457-3bcad021f8ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  },
];

export default function Example() {
  const [isRoundTrip, setIsRoundTrip] = useState(true);
  const value = isRoundTrip ? "round-trip" : "one-way";

  return (
    <Listbox
      value={value}
      onChange={(value) => setIsRoundTrip(value === "round-trip")}
    >
      {({ open }) => (
        <>
          <Listbox.Button
            className={
              "relative cursor-default w-full py-1.5 pl-3 pr-10 text-left text-gray-900 shadow-sm sm:text-sm sm:leading-6 " +
              (open ? "bg-indigo-600/[.06]" : "bg-white")
            }
          >
            <span className="flex items-center">
              {isRoundTrip ? <RoundTripIcon /> : <OneWayIcon />}
              <span className="ml-3 block truncate">
                {isRoundTrip ? "Gidiş-Dönüş" : "Tek Yön"}
              </span>
            </span>
            <span className="pointer-events-none absolute inset-y-0 right-0 ml-3 flex items-center pr-2">
              <DownIcon className="h-5 w-5 text-gray-400" aria-hidden="true" />
            </span>
          </Listbox.Button>
          <Listbox.Options className="absolute z-10 mt-1 max-h-56 w-56 overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
            <Listbox.Option
              className={
                "relative cursor-default select-none py-2 pl-3 pr-9 " +
                (isRoundTrip ? "bg-indigo-600 text-white" : "text-gray-900")
              }
              value="round-trip"
              static
            >
              <div className="flex items-center">
                <RoundTripIcon />
                <span
                  className={
                    "ml-3 block truncate " +
                    (isRoundTrip ? "font-semibold" : "font-normal")
                  }
                >
                  Gidiş-Dönüş
                </span>
              </div>
            </Listbox.Option>
            <Listbox.Option
              className={
                "relative cursor-default select-none py-2 pl-3 pr-9 " +
                (!isRoundTrip ? "bg-indigo-600 text-white" : "text-gray-900")
              }
              value="one-way"
              static
            >
              <div className="flex items-center">
                <OneWayIcon />
                <span
                  className={
                    "ml-3 block truncate " +
                    (!isRoundTrip ? "font-semibold" : "font-normal")
                  }
                >
                  Tek Yön
                </span>
              </div>
            </Listbox.Option>
          </Listbox.Options>
        </>
      )}
    </Listbox>
  );
}
