import React from "react";

function BookingType({ children, name, selected }) {
  let classList =
    "text-center p-4 text-black rounded-t flex items-center justify-center";
  classList += selected ? " bg-stone-100" : " bg-stone-300";

  return (
    <div className={classList}>
      {children} <span className="ml-4">{name}</span>
    </div>
  );
}

export default BookingType;
